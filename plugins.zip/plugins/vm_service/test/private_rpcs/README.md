This directory contains tests for private VM service RPCs.

**WARNING:** Functionality covered by these tests should not be relied on by clients not owned by the Dart and Flutter teams as private RPCs can and will be changed or removed without notice.