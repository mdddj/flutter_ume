// Copyright (c) 2017, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

// ignore: use_string_in_part_of_directives
part of breakpoint_in_parts_class;

void foo() {
  print('lalala');
}

class Foo1 {
  final String foo;

  Foo1(this.foo) {
    print('hello from foo!');
  }
}

class Foo2 {
  final String foo;

  Foo2(this.foo) {
    print('hello from foo!');
  }
}

class Foo3 {
  final String foo;

  Foo3(this.foo) {
    print('hello from foo!');
  }
}

class Foo4 {
  final String foo;

  Foo4(this.foo) {
    print('hello from foo!');
  }
}

class Foo5 {
  final String foo;

  Foo5(this.foo) {
    print('hello from foo!');
  }
}

class Foo6 {
  final String foo;

  Foo6(this.foo) {
    print('hello from foo!');
  }
}

class Foo7 {
  final String foo;

  Foo7(this.foo) {
    print('hello from foo!');
  }
}

class Foo8 {
  final String foo;

  Foo8(this.foo) {
    print('hello from foo!');
  }
}

class Foo9 {
  final String foo;

  Foo9(this.foo) {
    print('hello from foo!');
  }
}

class Foo10 {
  final String foo;

  Foo10(this.foo) {
    print('hello from foo!');
  }
}

var foo2 = foo() as dynamic;
