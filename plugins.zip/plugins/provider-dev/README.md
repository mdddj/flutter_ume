This is the source of the provider's devtool.

You can locally run it with:

```
flutter run -d chrome --dart-define=use_simulated_environment=true
```