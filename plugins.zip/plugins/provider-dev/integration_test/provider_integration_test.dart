// TODO: write integration test as proper integration test.
// See legacy test here:
// https://github.com/flutter/devtools/blob/master/packages/devtools_app/test/provider/provider_screen_integration_test.dart
